//Using for loop
function sumofArray(arr){
    let sum=0
    for(let i=0;i<arr.length;i++)
    {
        sum+= arr[i];
    }
    return sum;
}
let numbers = [6,8,9,4,3,2];
console.log(sumofArray(numbers));

//Using While loop
function sumofArray(arr){
    let sum=0;
    let i=0;
    while(i<arr.length){
    sum = arr[i];
    }
    return sum;
}
let numbers = [6,8,9,4,3,2];
console.log(sumofArray(numbers));

//Using Array Reduce Methode
function sumofArray(arr){
    return arr.reduce((a,b) => a+b,0);
}
let numbers = [6,8,9,4,3,2];
console.log(sumofArray(numbers));
