function isPrime(n){
    if(n<=1)return false;
    for(let i=2;i*i<=n;i++){
        if(n%i===0)return false;
    }
    return true;
}
let n=prompt("Enter any number:")
n=parseInt(n);
if (isPrime(n)){
    console.log(n+'is a prime Number');
}
else{
     console.log(n+' is not a prime Number');
}