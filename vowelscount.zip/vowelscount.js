function countvowels(str){
    let vowelcount = 0;
    for(let i=0;i<str.length;i++){
        let char = str.toLowerCase()[i];
        if(char==='a'||char==='e'||char==='i'||char==='o'||char==='u'){
            vowelcount++;
        }
    }
    return vowelcount;
}
let inputstring = prompt("Enter a String: ");
console.log("Number of vowels:",countvowels(inputstring));